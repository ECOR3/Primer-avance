package com.example.ecor3;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.graphics.drawable.Animatable;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

public class SplashActivity extends AppCompatActivity {
    //Inicializar variables
    ImageView ivTop,ivHeart,ivBeat,ivBottom;
    TextView textView;
    CharSequence charSequence;
    int index;
    long delay=200;
    Handler handler=new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        //Assingar variables
        ivTop=findViewById(R.id.iv_top);
        ivHeart=findViewById(R.id.iv_heart);
        ivBeat=findViewById(R.id.id_beat);
        ivBottom=findViewById(R.id.iv_bottom);
        textView=findViewById(R.id.text_view);

        //Establecer pantalla completa
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN
        ,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        //Inicilizar la animacion superior
        Animation animation1 = AnimationUtils.loadAnimation(this,R.anim.top_wave);

        //Inicializar la animacion superior
        ivTop.setAnimation(animation1);


        //Inicializar animadora de objetos
        ObjectAnimator objectAnimator =ObjectAnimator.ofPropertyValuesHolder(
                ivHeart,
                PropertyValuesHolder.ofFloat("scaleX",1.2f),
                PropertyValuesHolder.ofFloat("scaleY",1.2f)

        );
        //Establecer duracion
        objectAnimator.setDuration(500);
        //Establecer cuenta de repeticion
        objectAnimator.setRepeatCount(ValueAnimator.INFINITE);
        //Establecer el modo de repeticion
        objectAnimator.setRepeatMode(ValueAnimator.REVERSE);
        //Iniciar animadora
        objectAnimator.start();

        //establecer texto animado
        animatText("RECICLA");

        //Cargar gif
        Glide.with(this).load("https://firebasestorage.googleapis.com/v0/b/demoapp-ae96a.appspot.com/o/heart_beat.gif?alt=media&token=b21dddd8-782c-457c-babd-f2e922ba172b")
        .asGif()
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(ivBeat);

        //Inicializar boton de animacion
        Animation animation2=AnimationUtils.loadAnimation(this
        ,R.anim.bottom_wave);
        //Inicializar la animacion inferior
        ivBottom.setAnimation(animation2);

        //Inicializar controlador
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                //Redirigir la actividad principal
                startActivity(new Intent(SplashActivity.this
                ,MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                //Final de la actividad
                finish();

            }
        },4000);

    }

    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            //Cuando se ejecuta runnable
            //establecer texto
            textView.setText(charSequence.subSequence(0,index++));
            //comprobar condicion
            if (index <=charSequence.length()){
                //cuando el indice es igual a la longitud del texto
                //manejador de ejecucion
                handler.postDelayed(runnable,delay);
            }
        }
    };

    //Crear texto de metodo animado
    public void animatText(CharSequence cs){
        //establecer texto
        charSequence =cs;
        //limpiar index
        index=0;
        //limpiar texto
        textView.setText("");
        //Eliminar devolucion de llamada
        handler.removeCallbacks(runnable);
        //Manejador de ejecucion
        handler.postDelayed(runnable,delay);

    }
}